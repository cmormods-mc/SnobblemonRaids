# CobbleRaids — Phase 16: Reward GUI + Contribution Bonuses + Combat Rules

CobbleRaids is a cooperative wild-boss raid framework for **Cobblemon 1.7.3 on Minecraft 1.21.1/Fabric**.

Required runtime mods:

- Cobblemon 1.7.3
- SkiesGUIs 1.8.1
- Fabric API
- CobbleRaids

CobbleBoss and Raid Dens are **not dependencies**. They remain reference implementations used only for validation and architectural research.

## Current encounter loop

```text
natural wild raid boss
    -> right-click starts recruitment
    -> nearby players explicitly opt in
    -> countdown ends
    -> eligibility snapshot freezes
    -> boss HP scales to actual participant count
    -> one shared multi-player Cobblemon/Showdown raid
    -> shared canonical raid HP + contribution tracking
    -> victory OR defeat/timeout
    -> per-player SkiesGUIs reward GUI on victory
    -> one server-authoritative base choice
    -> contribution percentage bonus rolls
```

## Reward GUI

The bundled default is installed without overwriting operator edits at:

```text
config/skiesguis/guis/cobbleraids_reward.json
```

SkiesGUIs is presentation-only. The GUI buttons send:

```text
/cobbleraids reward claim candy
/cobbleraids reward claim balls
/cobbleraids reward claim gamble
```

CobbleRaids owns the pending reward token, validates the chosen option, consumes it once, grants the configured base/chance rewards, and resolves contribution bonus rolls. Closing the GUI does not consume the claim; `/cobbleraids reward` reopens the current pending reward.

## Contribution bonuses

Contribution percentage is normalized among reward-eligible winners:

```text
player applied raid damage / total applied raid damage by eligible winners * 100
```

Players who withdraw/flee/disconnect are not in the final reward denominator and receive no raid reward. The highest matching configured tier supplies the number of weighted bonus rolls.

Example:

```json
"contribution_bonus": {
  "enabled": true,
  "tiers": [
    {"min_percentage": 20.0, "bonus_rolls": 1},
    {"min_percentage": 35.0, "bonus_rolls": 2},
    {"min_percentage": 50.0, "bonus_rolls": 3}
  ],
  "pool": [
    {"item": "cobblemon:rare_candy", "amount": 1, "weight": 50},
    {"item": "cobblemon:ultra_ball", "amount": 3, "weight": 35},
    {"item": "cobblemon:exp_candy_l", "amount": 1, "weight": 15}
  ]
}
```

## Configurable combat rules

Global defaults now live in `config/cobbleraids/server.json`:

```json
"combat_defaults": {
  "time_limit_seconds": 900,
  "allow_flee": false
}
```

Each raid definition may override them:

```json
"time_limit_seconds": 900,
"allow_flee": false
```

`time_limit_seconds: 0` means unlimited.

### Flee disabled

CobbleRaids detects Cobblemon's `ForfeitActionResponse` before stock forfeit handling. The flee is rejected and the current battle choice is re-presented.

### Flee enabled

The player withdraws from the cooperative raid without ending everyone else's battle. Their Showdown side becomes inert, the boss stops targeting them, their battle UI closes, and they forfeit rewards. Their actor remains owned by the shared battle until final cleanup to avoid concurrent-party-state corruption.

### Disconnects

Cobblemon normally stops the entire battle when a participating player disconnects. For registered CobbleRaids battles this is intercepted and converted into a single-player withdrawal. The raid continues if at least one active participant remains.

### Timeout

The timer is server-authoritative and ticks only while a raid is ACTIVE. Warnings are currently sent at 60s, 30s, 10s, and 5..1s. Expiry is a defeat and never queues reward GUIs.

## Config layers

### `config/cobbleraids/server.json`

Operator-facing global tuning:

- natural spawn scheduler frequency/chance/caps;
- spawn distances and despawn defaults;
- recruitment duration/radius/max players;
- combat time limit default;
- flee default;
- debug logging.

### `data/cobbleraids/raids/*.json`

Per-boss content:

- species/level/base HP;
- biome/dimension/time/weight/cooldown spawn rules;
- recruitment overrides;
- player-count HP scaling;
- time limit/flee overrides;
- SkiesGUIs reward GUI id;
- base reward choices;
- chance rewards;
- contribution bonus tiers/pool.

## Validation

Run:

```text
validation/validate_phase16.sh
```

Phase 16 validates the real Cobblemon 1.7.3 forfeit, flee, disconnect, packet, and actor APIs; runs an exact timer unit test; runs a withdrawal simulation against Cobblemon's bundled Showdown; validates configs and mixins; then reruns the entire Phase 15 → Phase 14 → Phase 13 regression chain.

See `PHASE_16_VALIDATION.md` for the exact validation boundary and remaining live-server gate.
